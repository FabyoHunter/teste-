import sys
from pathlib import Path

file = Path(__file__).resolve()

sys.path.append(str(file.parents[1]))

from model.item import Item 
from controler.itemControler import ItemControler 

class JanelaItens:
    @staticmethod
    def mostrar_janela_cadastro_itens(database_name: str) -> None:
        """
        View para o usuário cadastrar novos itens no menu do restaurante.
        """
        print('\n---------- Cadastro de Novo Item no Menu ----------\n')
        
        while True:
           
            nome = str(input('Nome do Item: ')).strip()
            if not nome:
                print('❌ Nome não pode ser vazio. Por favor, digite um nome válido.')
                continue 
            
           
            while True: 
                try:
                    preco_input = input('Preço do Item (ex: 12.50): R$ ')
                    preco = float(preco_input)
                    if preco <= 0:
                        print('❌ Preço deve ser um valor positivo. Por favor, digite novamente.')
                        continue
                    break 
                except ValueError:
                    print('❌ Preço inválido! Por favor, digite um número.')
            
           
            tipo = str(input('Tipo do Item (ex: Pizza, Bebida, Sobremesa): ')).strip()
            if not tipo:
                print('❌ Tipo não pode ser vazio. Por favor, digite um tipo válido.')
                continue 
            
           
            novo_item = Item(nome, preco, tipo)

           
            result = ItemControler.insert_item_menu(database_name, novo_item)
            
            if result:
                print(f'\n✅ Item "{nome}" cadastrado com sucesso no menu!')
            else:
                print(f'\n❌ Erro ao cadastrar o item "{nome}". Tente novamente.')
            
           
            while True: 
                adicionar_mais = str(input('Deseja cadastrar outro item? (s/n): ')).lower().strip()
                if adicionar_mais == 's':
                    break
                elif adicionar_mais == 'n':
                    print('\nVoltando ao Menu Principal...\n')
                    return 
                else:
                    print('❌ Resposta inválida! Digite "s" para Sim ou "n" para Não.')
        
